import config from "./cypress.config.cjs";

export default config;
