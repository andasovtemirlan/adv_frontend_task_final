// Cypress support configuration
// Runs before each spec. Customize global behaviors here.

export {};