INSERT INTO positions ("teamId", name, description) VALUES 
(1, 'Developer', 'Software developer'),
(1, 'Project Manager', 'Manages the project'),
(1, 'QA Engineer', 'Quality assurance'),
(2, 'Lead Developer', 'Senior developer'),
(2, 'Developer', 'Software developer');
